import java.io.*;
import java.net.*;
import java.util.*;

public class client
{
	public static void main(String[] args)
	{
		try
		{
			Socket s=new Socket("localhost",1234);
			DataInputStream in=new DataInputStream(s.getInputStream());
			DataOutputStream out=new DataOutputStream(s.getOutputStream());
			Thread t1= new Thread()
			{
				public void run()
				{
					try
					{
						Scanner sc=new Scanner(System.in);
						String send=sc.nextLine();
						while(!send.equals("EXIT"))
						{
							out.writeUTF("Timothy_C: "+send);
							send=sc.nextLine();
						}
						out.writeUTF(send);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
			};
			Thread t2= new Thread()
			{
				public void run()
				{
					try
					{
						String rec=(String)in.readUTF();
						while(!rec.equals("EXIT"))
						{
							System.out.println(rec);
							rec=(String)in.readUTF();
						}
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
			};
			t1.start();
			t2.start();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}