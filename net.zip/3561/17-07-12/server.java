import java.io.*;
import java.net.*;
import java.util.*;

public class server
{
	public static void main(String[] args)
	{
		try
		{
			ServerSocket s=new ServerSocket(1234);
			Socket st=s.accept();
			DataInputStream in=new DataInputStream(st.getInputStream());
			DataOutputStream out=new DataOutputStream(st.getOutputStream());
			Thread t1= new Thread()
			{
				public void run()
				{
					try
					{
						Scanner sc=new Scanner(System.in);
						String send=sc.nextLine();
						while(!send.equals("EXIT"))
						{
							out.writeUTF("Timothy_S: "+send);
							send=sc.nextLine();
						}
						out.writeUTF(send);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
			};
			Thread t2= new Thread()
			{
				public void run()
				{
					try
					{
						String rec=(String)in.readUTF();
						while(!rec.equals("EXIT"))
						{
							System.out.println(rec);
							rec=(String)in.readUTF();
						}
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
			};
			t1.start();
			t2.start();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

