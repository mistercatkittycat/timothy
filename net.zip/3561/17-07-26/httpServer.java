import java.io.*;
import java.net.*;
import java.util.*;
import java.util.StringTokenizer;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class httpServer
{
	public static void main(String[] args) throws Exception
	{
		HttpServer server = HttpServer.create(new InetSocketAddress(1234), 0);
		String s = "/";
		server.createContext(s, new MyHandler());
		server.setExecutor(null);
		server.start();
	}

	static class MyHandler implements HttpHandler
	{
		public void handle(HttpExchange t) throws IOException
		{
			StringTokenizer st = new StringTokenizer(t.getRequestURI().toString(),"/");
			String header = st.nextToken();
			if(header.equals("GET"))
			{
				String fileName = "/";
				if(st.hasMoreElements() == false)
				{
					System.out.println("200 No File Requested...Returning index.html....");
					t.sendResponseHeaders(200, 0);
					byte[] buffer = new byte[1024];
					int bytes = 0 ;
					FileInputStream fin=new FileInputStream("index.html");
					OutputStream os = t.getResponseBody();
					while ((bytes = fin.read(buffer)) != -1 )
					{
						os.write(buffer, 0, bytes);
					}
					os.close();
					return;
				}
				while(st.hasMoreElements())
				{
					fileName += st.nextElement();
					fileName += "/";
				}
				fileName = fileName.substring(0,fileName.length()-1);
				System.out.println("FileName : " +fileName);
				FileInputStream fin = null;
				try
				{
					fin = new FileInputStream(fileName);
					System.out.println("200 File Found...");
					t.sendResponseHeaders(200, 0);
					byte[] buffer = new byte[1024];
					int bytes = 0 ;
					OutputStream os = t.getResponseBody();
					while ((bytes = fin.read(buffer)) != -1 )
					{
						os.write(buffer, 0, bytes);
					}
					os.close();
				}
				catch(FileNotFoundException e)
				{
					System.out.println("404 File Not Found...");
					byte [] response = "404 Object not found".getBytes();
					t.sendResponseHeaders(404, response.length);
					OutputStream os = t.getResponseBody();
					os.write(response);
					os.close();
				}
				catch(SecurityException e)
				{
					System.out.println("403 File Found...But read permission not available...");
					byte [] response = "403 forbidden".getBytes();
					t.sendResponseHeaders(403, response.length);
					OutputStream os = t.getResponseBody();
					os.write(response);
					os.close();
				}
				catch(Exception e)
				{
					System.out.println("400 Bad Request...");
					byte [] response = "400 Bad Request".getBytes();
					t.sendResponseHeaders(400, response.length);
					OutputStream os = t.getResponseBody();
					os.write(response);
					os.close();
				}
			}
			else
			{
				System.out.println("400 Bad Request...");
				byte [] response = "400 Bad Request".getBytes();
				t.sendResponseHeaders(400, response.length);
				OutputStream os = t.getResponseBody();
				os.write(response);
				os.close();
			}
		}
	}
}
