/*Write a server application which listens a given TCP port and it provides a simple http
Service to pass back a requested file in the server&#39;s directory or subdirectory. The request
from a browser should be in the form: &quot;GET /path/filename.xyz&quot;. If no file name or only
“ / ” in the request, the server passes the default index.html file from server’s directory. If
requested file is not found, it passes “404 Object not found”. If requested file is found but
it don’t have a permission to read, the servers passes “403 Forbidden”. If any other error
is occurred, the server passes “400 Bad request”. The program argument is the port
number. The default value of port number is 1234.*/

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.StringTokenizer;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

public class hv1{
  public static void main(String[] args) throws Exception{
    HttpServer server = HttpServer.create(new InetSocketAddress(1234), 0);
    String s = "/GET/home/student/Desktop/H3019/17-07-26/input.txt";
    server.createContext(s, new MyHandler(s));
    server.setExecutor(null); // creates a default executor
    server.start();
  }

  static class MyHandler implements HttpHandler {
    String s = null;
    public MyHandler(String ss){
	this.s = ss;
    }
    public void handle(HttpExchange t) throws IOException {
      StringTokenizer st = new StringTokenizer(s,"/");
      String header = st.nextToken();
      if(header.equals("GET")){
	String fileName = "";
	while(st.hasMoreElements()){
		fileName += st.nextElement();
		fileName += "/";
	}
	fileName = fileName.substring(0,fileName.length()-1);
        System.out.println("FileName : " +fileName);
        FileInputStream fin = null;
        boolean fileExist = true;
        try{
          fin = new FileInputStream(fileName);
        }
        catch(Exception e){ fileExist = false; }
        if(fileExist){
                byte [] response = "File found".getBytes();
                t.sendResponseHeaders(200, response.length);
                OutputStream os = t.getResponseBody();
                os.write(response);
                os.close();
        }
        else{
                byte [] response = "404 error file not found".getBytes();
                t.sendResponseHeaders(200, response.length);
                OutputStream os = t.getResponseBody();
                os.write(response);
                os.close();
        }
       if(fileExist){
                byte[] buffer = new byte[1024];
                int bytes = 0 ;
                while ((bytes = fin.read(buffer)) != -1 )  {
//                     os.write(buffer, 0, bytes);
                     for(int iCount=0;iCount<bytes;iCount++)   	{
                          int temp=buffer[iCount];
                          System.out.print((char)temp);
                     }
                }  
          }
        }
      }
   }
}
