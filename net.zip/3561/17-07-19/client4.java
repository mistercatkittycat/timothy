import java.util.*;
import java.net.*;
import java.io.*;
public class client4
{
	public static void main(String args[]) throws Exception
	{
		Socket s=new Socket("localhost",7);
		DataInputStream in=new DataInputStream(s.getInputStream());
		long l=in.readLong();
		System.out.println("Integer Date: "+l);
		System.out.println("Converted Date: "+new Date(l).toString());
	}
};