import java.util.*;
import java.net.*;
import java.io.*;
public class client5
{
	public static void main(String args[]) throws Exception
	{
		Socket s=new Socket("localhost",7);
		DataOutputStream out=new DataOutputStream(s.getOutputStream());
		DataInputStream in=new DataInputStream(s.getInputStream());
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			String st=sc.nextLine();
			if(st.equals("exit"))
				break;
			out.writeUTF(st);
			System.out.println(in.readUTF());
		}
	}
};