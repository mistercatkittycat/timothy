import java.util.*;
import java.net.*;
public class ex1
{
	public static void main(String args[]) throws Exception
	{
		InetAddress address= InetAddress.getLocalHost();
		System.out.println("IP: "+address.getHostAddress());
		System.out.println("Name: "+address.getHostName());
	}
};