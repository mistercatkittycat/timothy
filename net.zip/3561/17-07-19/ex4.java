import java.util.*;
import java.net.*;
import java.io.*;
public class ex4
{
	public static void main(String args[]) throws Exception
	{
		ServerSocket ser=new ServerSocket(7);
		while(true)
		{
			Socket s=ser.accept();
			DataOutputStream out=new DataOutputStream(s.getOutputStream());
			out.writeLong((new Date()).getTime());
			out.close();
			s.close();
		}
	}
};
