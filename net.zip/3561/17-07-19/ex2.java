import java.net.*;
import java.util.*;
import java.io.*;
public class ex2
{
	public static boolean isIP(String ip)
	{
	    if (ip == null)
	        return false;
	    String[] parts = ip.split("\\.");
	    if (parts.length != 4)
	        return false;
	    for (String s : parts)
	    {
	        try
	        {
	            int value = Integer.parseInt(s);
	            if (value <= 0 || value >= 255)
	                return false;
	        }
	        catch (Exception e)
	        {
	            return false;
	        }
	    }
	    return true;
	}
	public static void main(String args[]) throws Exception
	{
		Scanner in=new Scanner(new FileInputStream("in.txt"));
		while(true)
		{
			String s=in.nextLine();
			System.out.println("Input: "+s);
			if(s.equals("exit"))
				break;
			InetAddress add=InetAddress.getByName(s);
			if(isIP(s))
			{
				System.out.println("Hostname: "+add.getHostName());
			}
			else
			{
				System.out.println("IPAddress: "+add.getHostAddress());
			}
		}
	}
};
