import java.util.*;
import java.net.*;
import java.io.*;
public class ex5
{
	public static void main(String args[]) throws Exception
	{
		ServerSocket ser=new ServerSocket(7);
		Socket s=ser.accept();
		DataInputStream in=new DataInputStream(s.getInputStream());
		DataOutputStream out=new DataOutputStream(s.getOutputStream());
		while(true)
		{
			while(in.available()<=0);
			out.writeUTF(in.readUTF());
		}
	}
};
