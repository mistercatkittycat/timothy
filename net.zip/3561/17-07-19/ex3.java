import java.net.*;
import java.util.*;
import java.io.*;
public class ex3
{
	public static void main(String args[]) throws Exception
	{
		Socket s=new Socket("localhost",13);
		Scanner in=new Scanner(s.getInputStream());
		System.out.println("Date : " + in.nextLine());
		in.close();
		s.close();
	}
};